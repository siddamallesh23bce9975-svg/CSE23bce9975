const mongoose = require('mongoose');
const readline = require('readline');
const donorService = require('./services/donorService');
const categoryService = require('./services/categoryService');
const organizationService = require('./services/organizationService');
const donationService = require('./services/donationService');
const requestService = require('./services/requestService');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

const menuOptions = [
  'Manage Food Donors',
  'Manage Food Categories',
  'Manage Organizations',
  'Manage Food Donations',
  'Manage Food Requests',
  'Exit',
];

async function main() {
  await mongoose.connect('mongodb://127.0.0.1:27017/food_share_network', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });

  console.log('\nFood Share Network - Console Application');
  console.log('Connected to MongoDB.');

  while (true) {
    console.log('\nMain Menu:');
    menuOptions.forEach((option, index) => {
      console.log(`${index + 1}. ${option}`);
    });

    const choice = await ask('Choose an option: ');
    const selected = Number(choice);

    if (selected === 6) {
      console.log('Exiting application.');
      break;
    }

    switch (selected) {
      case 1:
        await donorService.showMenu();
        break;
      case 2:
        await categoryService.showMenu();
        break;
      case 3:
        await organizationService.showMenu();
        break;
      case 4:
        await donationService.showMenu();
        break;
      case 5:
        await requestService.showMenu();
        break;
      default:
        console.log('Invalid option. Try again.');
    }
  }

  rl.close();
  mongoose.disconnect();
}

function ask(question) {
  return new Promise((resolve) => rl.question(question, resolve));
}

main().catch((err) => {
  console.error('Error:', err.message);
  process.exit(1);
});
