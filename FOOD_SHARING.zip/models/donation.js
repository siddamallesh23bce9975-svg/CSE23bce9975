const mongoose = require('mongoose');

const donationSchema = new mongoose.Schema({
  donor: { type: mongoose.Schema.Types.ObjectId, ref: 'Donor', required: true },
  category: { type: mongoose.Schema.Types.ObjectId, ref: 'Category', required: true },
  quantity: { type: Number, required: true },
  foodDescription: { type: String, required: true },
  donationDate: { type: Date, default: Date.now },
  status: { type: String, enum: ['Available', 'Distributed'], default: 'Available' },
});

module.exports = mongoose.model('Donation', donationSchema);
