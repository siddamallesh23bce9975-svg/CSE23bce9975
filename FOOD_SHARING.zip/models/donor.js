const mongoose = require('mongoose');

const donorSchema = new mongoose.Schema({
  name: { type: String, required: true },
  contactNumber: { type: String, required: true },
  address: { type: String, required: true },
  email: { type: String },
  organizationType: { type: String, enum: ['Restaurant', 'Hotel', 'Individual'], default: 'Individual' },
});

module.exports = mongoose.model('Donor', donorSchema);
