const mongoose = require('mongoose');

const organizationSchema = new mongoose.Schema({
  name: { type: String, required: true },
  type: { type: String, enum: ['NGO', 'Orphanage', 'Old Age Home'], required: true },
  contactNumber: { type: String, required: true },
  address: { type: String, required: true },
  email: { type: String },
});

module.exports = mongoose.model('Organization', organizationSchema);
