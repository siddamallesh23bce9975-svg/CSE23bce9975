const statusElement = document.getElementById('status');
const categoryStatusElement = document.getElementById('categoryStatus');
const donationStatusElement = document.getElementById('donationStatus');
const receiverStatusElement = document.getElementById('receiverStatus');
const requestStatusElement = document.getElementById('requestStatus');

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (char) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
  }[char]));
}

function statusClass(status) {
  return String(status ?? '').toLowerCase();
}

async function api(path, options) {
  const response = await fetch(path, options);
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`API request failed: ${response.status} ${response.statusText} ${errorText}`);
  }
  return response.json();
}

async function refreshDonors({ clearStatus = true } = {}) {
  try {
    const donors = await api('/api/donors');
    const list = document.getElementById('donorList');
    const select = document.getElementById('donationDonor');
    if (!donors.length) {
      list.innerHTML = '<div class="empty-state">No donors added yet.</div>';
      select.innerHTML = '<option value="">Add a donor first</option>';
    } else {
      list.innerHTML = donors.map((donor) => `
        <div class="list-item">
          <div class="donor-name">${escapeHtml(donor.name)}</div>
          <div class="donor-meta">
            <span class="pill">${escapeHtml(donor.organizationType)}</span>
            <span>${escapeHtml(donor.contactNumber)}</span>
          </div>
        </div>
      `).join('');

      select.innerHTML = donors.map((donor) => `
        <option value="${escapeHtml(donor._id)}">${escapeHtml(donor.name)} (${escapeHtml(donor.organizationType)})</option>
      `).join('');
    }
    if (clearStatus) {
      statusElement.textContent = '';
    }
  } catch (err) {
    statusElement.textContent = 'Unable to load donors: ' + err.message;
    statusElement.style.color = 'red';
  }
}

async function refreshCategories() {
  try {
    const categories = await api('/api/categories');
    const select = document.getElementById('donationCategory');

    if (!categories.length) {
      select.innerHTML = '<option value="">No categories yet</option>';
      return;
    }

    select.innerHTML = categories.map((category) => `
      <option value="${escapeHtml(category._id)}">${escapeHtml(category.name)}</option>
    `).join('');
  } catch (err) {
    donationStatusElement.textContent = 'Unable to load categories: ' + err.message;
    donationStatusElement.style.color = 'red';
  }
}

async function refreshReceivers({ clearStatus = true } = {}) {
  try {
    const receivers = await api('/api/organizations');
    const list = document.getElementById('receiverList');
    const select = document.getElementById('requestOrganization');

    if (!receivers.length) {
      list.innerHTML = '<div class="empty-state">No receivers added yet.</div>';
      select.innerHTML = '<option value="">Add a receiver first</option>';
    } else {
      list.innerHTML = receivers.map((receiver) => `
        <div class="list-item">
          <div class="donor-name">${escapeHtml(receiver.name)}</div>
          <div class="donor-meta">
            <span class="pill">${escapeHtml(receiver.type)}</span>
            <span>${escapeHtml(receiver.contactNumber)}</span>
          </div>
        </div>
      `).join('');

      select.innerHTML = receivers.map((receiver) => `
        <option value="${escapeHtml(receiver._id)}">${escapeHtml(receiver.name)} (${escapeHtml(receiver.type)})</option>
      `).join('');
    }

    if (clearStatus) {
      receiverStatusElement.textContent = '';
    }
  } catch (err) {
    receiverStatusElement.textContent = 'Unable to load receivers: ' + err.message;
    receiverStatusElement.style.color = 'red';
  }
}

async function refreshDonations({ clearStatus = true } = {}) {
  try {
    const donations = await api('/api/donations');
    const select = document.getElementById('requestDonation');
    const list = document.getElementById('donationList');
    const availableDonations = donations.filter((donation) => donation.status === 'Available');

    if (!availableDonations.length) {
      select.innerHTML = '<option value="">No available donations yet</option>';
      list.innerHTML = '<div class="empty-state">No available food donations yet.</div>';
      return;
    }

    select.innerHTML = availableDonations.map((donation) => {
      const donorName = donation.donor?.name ?? 'Unknown donor';
      const categoryName = donation.category?.name ?? 'Food';
      const label = `${donation.foodDescription} - ${donation.quantity} (${categoryName}, ${donorName})`;
      return `<option value="${escapeHtml(donation._id)}">${escapeHtml(label)}</option>`;
    }).join('');

    list.innerHTML = availableDonations.map((donation) => {
      const donorName = donation.donor?.name ?? 'Unknown donor';
      const categoryName = donation.category?.name ?? 'Food';
      return `
        <div class="list-item">
          <div class="donor-name">${escapeHtml(donation.foodDescription)}</div>
          <div class="request-meta">
            <span class="pill ${escapeHtml(statusClass(donation.status))}">${escapeHtml(donation.status)}</span>
            <span>${escapeHtml(categoryName)}</span>
            <span class="quantity-badge">Remaining: ${escapeHtml(donation.quantity)}</span>
            <span>${escapeHtml(donorName)}</span>
          </div>
        </div>
      `;
    }).join('');

    if (clearStatus) {
      donationStatusElement.textContent = '';
    }
  } catch (err) {
    donationStatusElement.textContent = 'Unable to load donations: ' + err.message;
    donationStatusElement.style.color = 'red';
  }
}

async function refreshRequests({ clearStatus = true } = {}) {
  try {
    const requests = await api('/api/requests');
    const list = document.getElementById('requestList');

    if (!requests.length) {
      list.innerHTML = '<div class="empty-state">No food requests submitted yet.</div>';
    } else {
      list.innerHTML = requests.map((request) => {
        const organization = request.organization?.name ?? 'Unknown receiver';
        const donation = request.donation?.foodDescription ?? 'Unknown donation';
        const approveButton = request.status === 'Pending'
          ? `<button class="inline-button" data-approve-request="${escapeHtml(request._id)}">Approve</button>`
          : '';
        return `
          <div class="list-item">
            <div class="donor-name">${escapeHtml(organization)}</div>
            <div class="request-meta">
              <span class="pill ${escapeHtml(statusClass(request.status))}">${escapeHtml(request.status)}</span>
              <span>${escapeHtml(donation)}</span>
              <span>Qty: ${escapeHtml(request.requestedQuantity)}</span>
              ${approveButton}
            </div>
          </div>
        `;
      }).join('');
    }

    if (clearStatus) {
      requestStatusElement.textContent = '';
    }
  } catch (err) {
    requestStatusElement.textContent = 'Unable to load requests: ' + err.message;
    requestStatusElement.style.color = 'red';
  }
}

async function approveRequest(requestId) {
  try {
    await api(`/api/requests/${requestId}/approve`, { method: 'POST' });
    requestStatusElement.textContent = 'Request approved and food quantity updated.';
    requestStatusElement.style.color = '#207a4c';
    await refreshDonations({ clearStatus: false });
    await refreshRequests({ clearStatus: false });
  } catch (err) {
    requestStatusElement.textContent = 'Approve failed: ' + err.message;
    requestStatusElement.style.color = 'red';
    console.error(err);
  }
}

async function saveDonor() {
  const donor = {
    name: document.getElementById('donorName').value,
    contactNumber: document.getElementById('donorContact').value,
    address: document.getElementById('donorAddress').value,
    email: document.getElementById('donorEmail').value,
    organizationType: document.getElementById('donorType').value,
  };

  try {
    await api('/api/donors', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(donor),
    });

    document.getElementById('donorName').value = '';
    document.getElementById('donorContact').value = '';
    document.getElementById('donorAddress').value = '';
    document.getElementById('donorEmail').value = '';
    statusElement.textContent = 'Donor saved successfully.';
    statusElement.style.color = '#207a4c';
    await refreshDonors({ clearStatus: false });
  } catch (err) {
    statusElement.textContent = 'Save failed: ' + err.message;
    statusElement.style.color = 'red';
    console.error(err);
  }
}

async function saveReceiver() {
  const receiver = {
    name: document.getElementById('receiverName').value,
    contactNumber: document.getElementById('receiverContact').value,
    address: document.getElementById('receiverAddress').value,
    email: document.getElementById('receiverEmail').value,
    type: document.getElementById('receiverType').value,
  };

  try {
    await api('/api/organizations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(receiver),
    });

    document.getElementById('receiverName').value = '';
    document.getElementById('receiverContact').value = '';
    document.getElementById('receiverAddress').value = '';
    document.getElementById('receiverEmail').value = '';
    receiverStatusElement.textContent = 'Receiver saved successfully.';
    receiverStatusElement.style.color = '#207a4c';
    await refreshReceivers({ clearStatus: false });
  } catch (err) {
    receiverStatusElement.textContent = 'Save failed: ' + err.message;
    receiverStatusElement.style.color = 'red';
    console.error(err);
  }
}

async function saveCategory() {
  const name = document.getElementById('categoryName').value;
  const description = document.getElementById('categoryDescription').value;

  if (!name) {
    categoryStatusElement.textContent = 'Enter a category name.';
    categoryStatusElement.style.color = 'red';
    return;
  }

  try {
    await api('/api/categories', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, description }),
    });

    document.getElementById('categoryName').value = '';
    document.getElementById('categoryDescription').value = '';
    categoryStatusElement.textContent = 'Category saved successfully.';
    categoryStatusElement.style.color = '#207a4c';
    await refreshCategories();
  } catch (err) {
    categoryStatusElement.textContent = 'Category failed: ' + err.message;
    categoryStatusElement.style.color = 'red';
    console.error(err);
  }
}

async function saveDonation() {
  const donor = document.getElementById('donationDonor').value;
  const category = document.getElementById('donationCategory').value;
  const quantity = Number(document.getElementById('donationQuantity').value);
  const foodDescription = document.getElementById('donationDescription').value;

  if (!donor || !category || !quantity || !foodDescription) {
    donationStatusElement.textContent = 'Choose donor, category, quantity, and food description.';
    donationStatusElement.style.color = 'red';
    return;
  }

  try {
    await api('/api/donations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ donor, category, quantity, foodDescription }),
    });

    document.getElementById('donationQuantity').value = '';
    document.getElementById('donationDescription').value = '';
    donationStatusElement.textContent = 'Donation saved successfully.';
    donationStatusElement.style.color = '#207a4c';
    await refreshDonations({ clearStatus: false });
  } catch (err) {
    donationStatusElement.textContent = 'Donation failed: ' + err.message;
    donationStatusElement.style.color = 'red';
    console.error(err);
  }
}

async function saveRequest() {
  const organization = document.getElementById('requestOrganization').value;
  const donation = document.getElementById('requestDonation').value;
  const requestedQuantity = Number(document.getElementById('requestQuantity').value);

  if (!organization || !donation || !requestedQuantity) {
    requestStatusElement.textContent = 'Choose receiver, donation, and quantity.';
    requestStatusElement.style.color = 'red';
    return;
  }

  try {
    const savedRequest = await api('/api/requests', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ organization, donation, requestedQuantity }),
    });

    document.getElementById('requestQuantity').value = '';
    if (savedRequest.status === 'Fulfilled') {
      requestStatusElement.textContent = 'Food request fulfilled and quantity updated.';
      requestStatusElement.style.color = '#207a4c';
    } else {
      requestStatusElement.textContent = `Food request ${savedRequest.status.toLowerCase()}. Check available quantity.`;
      requestStatusElement.style.color = savedRequest.status === 'Rejected' ? 'red' : '#207a4c';
    }
    await refreshDonations({ clearStatus: false });
    await refreshRequests({ clearStatus: false });
  } catch (err) {
    requestStatusElement.textContent = 'Request failed: ' + err.message;
    requestStatusElement.style.color = 'red';
    console.error(err);
  }
}

document.getElementById('saveDonor').addEventListener('click', saveDonor);
document.getElementById('saveCategory').addEventListener('click', saveCategory);
document.getElementById('saveDonation').addEventListener('click', saveDonation);
document.getElementById('saveReceiver').addEventListener('click', saveReceiver);
document.getElementById('saveRequest').addEventListener('click', saveRequest);
document.getElementById('requestList').addEventListener('click', (event) => {
  const button = event.target.closest('[data-approve-request]');
  const requestId = button?.dataset.approveRequest;
  if (requestId) {
    approveRequest(requestId);
  }
});

Promise.all([
  refreshDonors(),
  refreshCategories(),
  refreshReceivers(),
  refreshDonations(),
  refreshRequests(),
]).catch((err) => {
  statusElement.textContent = 'Failed to initialize: ' + err.message;
  statusElement.style.color = 'red';
  console.error(err);
});
