const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const Donor = require('./models/donor');
const Category = require('./models/category');
const Organization = require('./models/organization');
const Donation = require('./models/donation');
const Request = require('./models/request');

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

async function connectDatabase() {
  await mongoose.connect('mongodb://127.0.0.1:27017/food_share_network', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });
}

async function approveFoodRequest(request) {
  const donation = await Donation.findById(request.donation);
  if (!donation) {
    request.status = 'Rejected';
    await request.save();
    return { request, error: 'Donation not found' };
  }

  if (donation.status !== 'Available' || donation.quantity < request.requestedQuantity) {
    request.status = 'Rejected';
    await request.save();
    return { request, error: `Only ${donation.quantity} item(s) available.` };
  }

  donation.quantity -= request.requestedQuantity;
  if (donation.quantity === 0) {
    donation.status = 'Distributed';
  }

  request.status = 'Fulfilled';
  await donation.save();
  await request.save();

  return { request, donation };
}

app.get('/api/donors', async (req, res) => {
  const donors = await Donor.find();
  res.json(donors);
});

app.post('/api/donors', async (req, res) => {
  const donor = new Donor(req.body);
  await donor.save();
  res.status(201).json(donor);
});

app.get('/api/categories', async (req, res) => {
  const categories = await Category.find();
  res.json(categories);
});

app.post('/api/categories', async (req, res) => {
  const category = new Category(req.body);
  await category.save();
  res.status(201).json(category);
});

app.get('/api/organizations', async (req, res) => {
  const organizations = await Organization.find();
  res.json(organizations);
});

app.post('/api/organizations', async (req, res) => {
  const organization = new Organization(req.body);
  await organization.save();
  res.status(201).json(organization);
});

app.get('/api/donations', async (req, res) => {
  const donations = await Donation.find().populate('donor category');
  res.json(donations);
});

app.post('/api/donations', async (req, res) => {
  const donation = new Donation(req.body);
  await donation.save();
  res.status(201).json(donation);
});

app.get('/api/requests', async (req, res) => {
  const requests = await Request.find().populate('organization donation');
  res.json(requests);
});

app.post('/api/requests', async (req, res) => {
  const requestedQuantity = Number(req.body.requestedQuantity);
  if (!requestedQuantity || requestedQuantity <= 0) {
    return res.status(400).json({ error: 'Requested quantity must be greater than 0.' });
  }

  const request = new Request({ ...req.body, requestedQuantity });
  await request.save();

  const result = await approveFoodRequest(request);
  const savedRequest = await Request.findById(result.request._id).populate('organization donation');
  res.status(201).json(savedRequest);
});

app.post('/api/requests/:id/approve', async (req, res) => {
  const request = await Request.findById(req.params.id);
  if (!request) return res.status(404).json({ error: 'Request not found' });
  if (request.status !== 'Pending') {
    return res.status(400).json({ error: `Request is already ${request.status}.` });
  }

  const result = await approveFoodRequest(request);
  const savedRequest = await Request.findById(result.request._id).populate('organization donation');
  res.json(savedRequest);
});

app.put('/api/donations/:id/status', async (req, res) => {
  const donation = await Donation.findById(req.params.id);
  if (!donation) return res.status(404).json({ error: 'Donation not found' });
  donation.status = req.body.status;
  await donation.save();
  res.json(donation);
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: err.message });
});

connectDatabase()
  .then(() => {
    app.listen(port, () => {
      console.log(`Web server running at http://localhost:${port}`);
    });
  })
  .catch((err) => {
    console.error('Database connection failed:', err);
    process.exit(1);
  });
