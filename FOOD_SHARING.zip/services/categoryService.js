const Category = require('../models/category');
const { ask, printList } = require('./commonService');

async function createCategory() {
  const name = await ask('Category name: ');
  const description = await ask('Description: ');
  const category = new Category({ name, description });
  await category.save();
  console.log('Category added successfully.');
}

async function listCategories() {
  const categories = await Category.find();
  if (!categories.length) {
    console.log('No categories found.');
    return;
  }
  categories.forEach((category) => {
    console.log(`- ${category._id}: ${category.name} - ${category.description || 'No description'}`);
  });
}

async function updateCategory() {
  await listCategories();
  const id = await ask('Enter category id to update: ');
  const category = await Category.findById(id);
  if (!category) {
    console.log('Category not found.');
    return;
  }
  category.name = await ask(`Name (${category.name}): `) || category.name;
  category.description = await ask(`Description (${category.description || ''}): `) || category.description;
  await category.save();
  console.log('Category updated successfully.');
}

async function deleteCategory() {
  await listCategories();
  const id = await ask('Enter category id to delete: ');
  await Category.findByIdAndDelete(id);
  console.log('Category deleted if existed.');
}

async function showMenu() {
  while (true) {
    console.log('\nFood Category Management:');
    printList(['Add category', 'List categories', 'Update category', 'Delete category', 'Back']);
    const choice = Number(await ask('Choose an option: '));
    if (choice === 5) break;
    switch (choice) {
      case 1:
        await createCategory();
        break;
      case 2:
        await listCategories();
        break;
      case 3:
        await updateCategory();
        break;
      case 4:
        await deleteCategory();
        break;
      default:
        console.log('Invalid option.');
    }
  }
}

module.exports = { showMenu };
