const rl = require('readline').createInterface({
  input: process.stdin,
  output: process.stdout,
});

function ask(question) {
  return new Promise((resolve) => rl.question(question, resolve));
}

function printList(items) {
  items.forEach((item, index) => console.log(`${index + 1}. ${item}`));
}

function close() {
  rl.close();
}

module.exports = { ask, printList, close };
