const Donation = require('../models/donation');
const Donor = require('../models/donor');
const Category = require('../models/category');
const { ask, printList } = require('./commonService');

async function chooseDonor() {
  const donors = await Donor.find();
  if (!donors.length) {
    console.log('No donors available. Please add a donor first.');
    return null;
  }
  donors.forEach((donor, index) => console.log(`${index + 1}. ${donor.name} (${donor.organizationType})`));
  const choice = Number(await ask('Pick a donor number: '));
  return donors[choice - 1] || null;
}

async function chooseCategory() {
  const categories = await Category.find();
  if (!categories.length) {
    console.log('No categories available. Please add a category first.');
    return null;
  }
  categories.forEach((category, index) => console.log(`${index + 1}. ${category.name}`));
  const choice = Number(await ask('Pick a category number: '));
  return categories[choice - 1] || null;
}

async function createDonation() {
  const donor = await chooseDonor();
  if (!donor) return;
  const category = await chooseCategory();
  if (!category) return;
  const quantity = Number(await ask('Quantity (units): '));
  const foodDescription = await ask('Food description: ');

  const donation = new Donation({ donor: donor._id, category: category._id, quantity, foodDescription });
  await donation.save();
  console.log('Donation recorded successfully.');
}

async function listDonations() {
  const donations = await Donation.find().populate('donor category');
  if (!donations.length) {
    console.log('No donations found.');
    return;
  }
  donations.forEach((donation) => {
    console.log(`- ${donation._id}: ${donation.foodDescription} (${donation.quantity}) from ${donation.donor.name} / ${donation.category.name} [${donation.status}]`);
  });
}

async function updateDonationStatus() {
  await listDonations();
  const id = await ask('Enter donation id to update status: ');
  const donation = await Donation.findById(id);
  if (!donation) {
    console.log('Donation not found.');
    return;
  }
  donation.status = await ask(`Status (${donation.status}): `) || donation.status;
  await donation.save();
  console.log('Donation status updated successfully.');
}

async function deleteDonation() {
  await listDonations();
  const id = await ask('Enter donation id to delete: ');
  await Donation.findByIdAndDelete(id);
  console.log('Donation deleted if existed.');
}

async function showMenu() {
  while (true) {
    console.log('\nFood Donation Management:');
    printList(['Record donation', 'List donations', 'Update donation status', 'Delete donation', 'Back']);
    const choice = Number(await ask('Choose an option: '));
    if (choice === 5) break;
    switch (choice) {
      case 1:
        await createDonation();
        break;
      case 2:
        await listDonations();
        break;
      case 3:
        await updateDonationStatus();
        break;
      case 4:
        await deleteDonation();
        break;
      default:
        console.log('Invalid option.');
    }
  }
}

module.exports = { showMenu };
