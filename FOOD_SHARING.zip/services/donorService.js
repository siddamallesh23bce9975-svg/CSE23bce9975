const Donor = require('../models/donor');
const { ask, printList } = require('./commonService');

async function createDonor() {
  const name = await ask('Donor name: ');
  const contactNumber = await ask('Contact number: ');
  const address = await ask('Address: ');
  const email = await ask('Email (optional): ');
  const organizationType = await ask('Organization type (Restaurant/Hotel/Individual): ');

  const donor = new Donor({ name, contactNumber, address, email, organizationType });
  await donor.save();
  console.log('Donor added successfully.');
}

async function listDonors() {
  const donors = await Donor.find();
  if (!donors.length) {
    console.log('No donors found.');
    return;
  }
  donors.forEach((donor) => {
    console.log(`- ${donor._id}: ${donor.name} (${donor.organizationType}) - ${donor.contactNumber}`);
  });
}

async function updateDonor() {
  await listDonors();
  const id = await ask('Enter donor id to update: ');
  const donor = await Donor.findById(id);
  if (!donor) {
    console.log('Donor not found.');
    return;
  }
  donor.name = await ask(`Name (${donor.name}): `) || donor.name;
  donor.contactNumber = await ask(`Contact number (${donor.contactNumber}): `) || donor.contactNumber;
  donor.address = await ask(`Address (${donor.address}): `) || donor.address;
  donor.email = await ask(`Email (${donor.email || ''}): `) || donor.email;
  donor.organizationType = await ask(`Organization type (${donor.organizationType}): `) || donor.organizationType;
  await donor.save();
  console.log('Donor updated successfully.');
}

async function deleteDonor() {
  await listDonors();
  const id = await ask('Enter donor id to delete: ');
  await Donor.findByIdAndDelete(id);
  console.log('Donor deleted if existed.');
}

async function showMenu() {
  while (true) {
    console.log('\nFood Donor Management:');
    printList(['Add donor', 'List donors', 'Update donor', 'Delete donor', 'Back']);
    const choice = Number(await ask('Choose an option: '));
    if (choice === 5) break;
    switch (choice) {
      case 1:
        await createDonor();
        break;
      case 2:
        await listDonors();
        break;
      case 3:
        await updateDonor();
        break;
      case 4:
        await deleteDonor();
        break;
      default:
        console.log('Invalid option.');
    }
  }
}

module.exports = { showMenu };
