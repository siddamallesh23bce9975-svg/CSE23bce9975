const Organization = require('../models/organization');
const { ask, printList } = require('./commonService');

async function createOrganization() {
  const name = await ask('Organization name: ');
  const type = await ask('Type (NGO/Orphanage/Old Age Home): ');
  const contactNumber = await ask('Contact number: ');
  const address = await ask('Address: ');
  const email = await ask('Email (optional): ');

  const organization = new Organization({ name, type, contactNumber, address, email });
  await organization.save();
  console.log('Organization added successfully.');
}

async function listOrganizations() {
  const organizations = await Organization.find();
  if (!organizations.length) {
    console.log('No organizations found.');
    return;
  }
  organizations.forEach((organization) => {
    console.log(`- ${organization._id}: ${organization.name} (${organization.type}) - ${organization.contactNumber}`);
  });
}

async function updateOrganization() {
  await listOrganizations();
  const id = await ask('Enter organization id to update: ');
  const organization = await Organization.findById(id);
  if (!organization) {
    console.log('Organization not found.');
    return;
  }
  organization.name = await ask(`Name (${organization.name}): `) || organization.name;
  organization.type = await ask(`Type (${organization.type}): `) || organization.type;
  organization.contactNumber = await ask(`Contact number (${organization.contactNumber}): `) || organization.contactNumber;
  organization.address = await ask(`Address (${organization.address}): `) || organization.address;
  organization.email = await ask(`Email (${organization.email || ''}): `) || organization.email;
  await organization.save();
  console.log('Organization updated successfully.');
}

async function deleteOrganization() {
  await listOrganizations();
  const id = await ask('Enter organization id to delete: ');
  await Organization.findByIdAndDelete(id);
  console.log('Organization deleted if existed.');
}

async function showMenu() {
  while (true) {
    console.log('\nOrganization Management:');
    printList(['Add organization', 'List organizations', 'Update organization', 'Delete organization', 'Back']);
    const choice = Number(await ask('Choose an option: '));
    if (choice === 5) break;
    switch (choice) {
      case 1:
        await createOrganization();
        break;
      case 2:
        await listOrganizations();
        break;
      case 3:
        await updateOrganization();
        break;
      case 4:
        await deleteOrganization();
        break;
      default:
        console.log('Invalid option.');
    }
  }
}

module.exports = { showMenu };
