const Request = require('../models/request');
const Organization = require('../models/organization');
const Donation = require('../models/donation');
const { ask, printList } = require('./commonService');

async function chooseOrganization() {
  const organizations = await Organization.find();
  if (!organizations.length) {
    console.log('No organizations available. Please add an organization first.');
    return null;
  }
  organizations.forEach((org, index) => console.log(`${index + 1}. ${org.name} (${org.type})`));
  const choice = Number(await ask('Pick an organization number: '));
  return organizations[choice - 1] || null;
}

async function chooseDonation() {
  const donations = await Donation.find({ status: 'Available' }).populate('donor category');
  if (!donations.length) {
    console.log('No available donations found.');
    return null;
  }
  donations.forEach((donation, index) => {
    console.log(`${index + 1}. ${donation.foodDescription} (${donation.quantity}) from ${donation.donor.name}`);
  });
  const choice = Number(await ask('Pick a donation number: '));
  return donations[choice - 1] || null;
}

async function createRequest() {
  const organization = await chooseOrganization();
  if (!organization) return;
  const donation = await chooseDonation();
  if (!donation) return;
  const requestedQuantity = Number(await ask('Requested quantity: '));

  const request = new Request({
    organization: organization._id,
    donation: donation._id,
    requestedQuantity,
  });
  await request.save();
  console.log('Request created successfully.');
}

async function listRequests() {
  const requests = await Request.find().populate('organization donation');
  if (!requests.length) {
    console.log('No requests found.');
    return;
  }
  requests.forEach((req) => {
    console.log(`- ${req._id}: ${req.organization.name} requested ${req.requestedQuantity} from donation ${req.donation.foodDescription} [${req.status}]`);
  });
}

async function updateRequestStatus() {
  await listRequests();
  const id = await ask('Enter request id to update status: ');
  const request = await Request.findById(id).populate('donation');
  if (!request) {
    console.log('Request not found.');
    return;
  }
  request.status = await ask(`Status (${request.status}): `) || request.status;
  await request.save();
  if (request.status === 'Fulfilled') {
    request.donation.status = 'Distributed';
    await request.donation.save();
  }
  console.log('Request status updated successfully.');
}

async function deleteRequest() {
  await listRequests();
  const id = await ask('Enter request id to delete: ');
  await Request.findByIdAndDelete(id);
  console.log('Request deleted if existed.');
}

async function showMenu() {
  while (true) {
    console.log('\nFood Request Management:');
    printList(['Create request', 'List requests', 'Update request status', 'Delete request', 'Back']);
    const choice = Number(await ask('Choose an option: '));
    if (choice === 5) break;
    switch (choice) {
      case 1:
        await createRequest();
        break;
      case 2:
        await listRequests();
        break;
      case 3:
        await updateRequestStatus();
        break;
      case 4:
        await deleteRequest();
        break;
      default:
        console.log('Invalid option.');
    }
  }
}

module.exports = { showMenu };
